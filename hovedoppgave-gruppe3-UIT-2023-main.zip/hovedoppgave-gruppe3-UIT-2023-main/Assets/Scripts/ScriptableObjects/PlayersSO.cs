using UnityEngine;

[CreateAssetMenu]
public class PlayersSO : ScriptableObject
{
    public int nPlayers;
}
