using Unity.Netcode;

public class PlayerGameStatus : NetworkBehaviour
{

}
