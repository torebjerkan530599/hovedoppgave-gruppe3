using UnityEngine;

public class LobbyJoinByCodeMenu : MonoBehaviour
{
    private void Start()
    {

    }
}
